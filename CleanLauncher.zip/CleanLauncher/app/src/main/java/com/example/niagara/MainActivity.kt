package com.example.niagara

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.exp
import kotlin.math.roundToInt

data class AppItem(val label: String, val pkg: String)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Launcher(tick) } }
    }
    override fun onResume() { super.onResume(); tick++ }
}

fun loadApps(ctx: Context): List<AppItem> {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return ctx.packageManager.queryIntentActivities(i, 0)
        .map { AppItem(it.loadLabel(ctx.packageManager).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun launch(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

@Composable
fun Launcher(tick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val apps = remember(tick) { loadApps(ctx) }
    var favs by remember { mutableStateOf(prefs.getString("favs", "")!!.split("|").filter { it.isNotEmpty() }) }
    fun toggleFav(pkg: String) {
        favs = if (pkg in favs) favs - pkg else favs + pkg
        prefs.edit().putString("favs", favs.joinToString("|")).apply()
    }
    var drawer by remember { mutableStateOf(false) }
    val badges by NotificationService.counts.collectAsState()
    BackHandler(drawer) { drawer = false }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (drawer) 0.85f else 0.35f))
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc < -150f) drawer = true }
                ) { _, d -> acc += d }
            }
    ) {
        if (drawer) Drawer(apps, favs, badges, ::toggleFav, onClose = { drawer = false })
        else Home(apps, favs, badges, tick, ::toggleFav, onAll = { drawer = true })
    }
}

@Composable
fun Home(apps: List<AppItem>, favs: List<String>, badges: Map<String, Int>, tick: Int,
         onFav: (String) -> Unit, onAll: () -> Unit) {
    val ctx = LocalContext.current
    val time by produceState("", tick) {
        while (true) {
            value = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); delay(10_000)
        }
    }
    val date = SimpleDateFormat("EEEE, d. MMMM", Locale.getDefault()).format(Date())
    val notifOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(vertical = 16.dp), horizontalAlignment = Alignment.End) {
        Text(time, fontSize = 56.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(horizontal = 24.dp))
        Text(date, fontSize = 16.sp, color = Color.White.copy(0.7f), modifier = Modifier.padding(horizontal = 24.dp))
        Spacer(Modifier.weight(1f))
        favs.mapNotNull { f -> apps.find { it.pkg == f } }.forEach {
            AppRow(it, true, badges[it.pkg] ?: 0, 32.sp) { onFav(it.pkg) }
        }
        if (favs.isEmpty()) Text("Wische nach oben und halte eine App gedrückt, um sie hier anzuheften.",
            color = Color.White.copy(0.6f), modifier = Modifier.padding(24.dp))
        Spacer(Modifier.height(16.dp))
        if (!notifOn) Text("Benachrichtigungen aktivieren", color = Color(0xFF80CBC4), fontSize = 14.sp,
            modifier = Modifier.clickable {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }.padding(horizontal = 24.dp, vertical = 8.dp))
        Text("Alle Apps", color = Color.White.copy(0.7f), fontSize = 16.sp,
            modifier = Modifier.clickable { onAll() }.padding(horizontal = 24.dp, vertical = 8.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRow(app: AppItem, isFav: Boolean, badge: Int, size: TextUnit, onFav: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.combinedClickable(onClick = { launch(ctx, app.pkg) }, onLongClick = { menu = true })
                .padding(horizontal = 24.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (badge > 0) Text("$badge", color = Color(0xFF80CBC4), fontSize = 14.sp, modifier = Modifier.padding(end = 8.dp))
            Text(app.label, color = Color.White, fontSize = size, maxLines = 1)
        }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text(if (isFav) "Von Favoriten entfernen" else "Zu Favoriten") },
                onClick = { menu = false; onFav() })
            DropdownMenuItem(text = { Text("App-Info") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
            })
            DropdownMenuItem(text = { Text("Deinstallieren") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            })
        }
    }
}

@Composable
fun Drawer(apps: List<AppItem>, favs: List<String>, badges: Map<String, Int>,
           onFav: (String) -> Unit, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val list = remember(apps, query) { apps.filter { it.label.contains(query, true) } }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val letters = remember(list) {
        list.map { it.label.firstOrNull()?.uppercaseChar()?.takeIf { c -> c.isLetter() } ?: '#' }.distinct()
    }
    Row(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.weight(1f)) {
            OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Suchen") },
                modifier = Modifier.fillMaxWidth().padding(16.dp))
            LazyColumn(state = state, modifier = Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { app ->
                    AppRow(app, app.pkg in favs, badges[app.pkg] ?: 0, 24.sp) { onFav(app.pkg) }
                }
            }
        }
        if (letters.isNotEmpty()) LetterSlider(letters) { c ->
            val idx = list.indexOfFirst {
                (it.label.firstOrNull()?.uppercaseChar()?.takeIf { x -> x.isLetter() } ?: '#') == c
            }
            if (idx >= 0) scope.launch { state.scrollToItem(idx) }
        }
    }
}

@Composable
fun LetterSlider(letters: List<Char>, onSelect: (Char) -> Unit) {
    var active by remember { mutableFloatStateOf(-1f) }
    var h by remember { mutableIntStateOf(1) }
    fun update(y: Float) {
        val i = (y / h * letters.size).coerceIn(0f, letters.size - 1f)
        active = i; onSelect(letters[i.toInt()])
    }
    Column(
        Modifier.fillMaxHeight().width(56.dp).onSizeChanged { h = it.height }
            .pointerInput(letters) {
                detectDragGestures(
                    onDragStart = { update(it.y) },
                    onDragEnd = { active = -1f },
                    onDragCancel = { active = -1f }
                ) { change, _ -> update(change.position.y) }
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEachIndexed { i, c ->
            val d = if (active < 0) 99f else i - active
            val wave = exp(-(d * d) / 3.0).toFloat()
            Text("$c", color = Color.White.copy(0.5f + 0.5f * wave), fontSize = (13 + 12 * wave).sp,
                modifier = Modifier.offset { IntOffset((-70 * wave).roundToInt(), 0) })
        }
    }
}
