package com.example.niagara

import android.Manifest
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.exp
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

data class AppItem(val label: String, val pkg: String)
data class Bg(val name: String, val colors: List<Color> = emptyList(), val motif: Int = -1)

fun col(x: Int) = Color(0xFF000000.toInt() or x)

// Alles statisch und dunkel: wird nur einmal gezeichnet, spart Akku (OLED).
val BACKGROUNDS = listOf(
    Bg("Wallpaper"),
    Bg("Schwarz", listOf(col(0x000000))),
    Bg("Anthrazit", listOf(col(0x121212))),
    Bg("Mitternacht", listOf(col(0x0B1020))),
    Bg("Tiefblau", listOf(col(0x0A1A2F))),
    Bg("Bordeaux", listOf(col(0x1E0A10))),
    Bg("Graphit", listOf(col(0x000000), col(0x202226))),
    Bg("Smaragd", listOf(col(0x000000), col(0x0A2A1E))),
    Bg("Schwarzer Strand", listOf(col(0x000000)), 0),
    Bg("Sternenhimmel", listOf(col(0x000000)), 1),
    Bg("Berge", listOf(col(0x000000)), 2),
    Bg("Dünen", listOf(col(0x000000)), 3),
    Bg("Mond & Meer", listOf(col(0x000000)), 4),
    Bg("Wald", listOf(col(0x000000)), 5),
    Bg("Nordlicht", listOf(col(0x000000)), 6),
    Bg("Skyline", listOf(col(0x000000)), 7),
    Bg("Planet", listOf(col(0x000000)), 8),
    Bg("Wellen", listOf(col(0x000000)), 9),
    Bg("Sonnenuntergang", listOf(col(0x000000)), 10),
    Bg("Kreise", listOf(col(0x000000), col(0x10141C)), 11),
    Bg("Clean Launcher", listOf(col(0x000000)), 12),
    Bg("Eigenes Bild", listOf(col(0x000000)), 99)
)

fun bgModifier(cols: List<Color>, wallpaperAlpha: Float): Modifier = when (cols.size) {
    0 -> Modifier.background(Color.Black.copy(alpha = wallpaperAlpha))
    1 -> Modifier.background(cols[0])
    else -> Modifier.background(Brush.verticalGradient(cols))
}

fun DrawScope.ridge(y: Float, amp: Float, f: Float, ph: Float, c: Color) {
    val p = Path()
    p.moveTo(0f, size.height)
    var x = 0f
    val step = size.width / 48f
    while (x <= size.width + 1f) {
        val a = x / size.width * f + ph
        p.lineTo(x, y + amp * (sin(a) + 0.5f * sin(2.3f * a + 1f)))
        x += step
    }
    p.lineTo(size.width, size.height)
    p.close()
    drawPath(p, c)
}

fun DrawScope.stars(n: Int, seed: Int, maxY: Float) {
    val r = Random(seed)
    repeat(n) {
        drawCircle(Color.White.copy(0.2f + 0.6f * r.nextFloat()), 1f + 1.5f * r.nextFloat(),
            Offset(size.width * r.nextFloat(), size.height * maxY * r.nextFloat()))
    }
}

fun DrawScope.motif(id: Int) {
    val w = size.width
    val ht = size.height
    fun sky(a: Color, b: Color, end: Float = 1f) =
        drawRect(Brush.verticalGradient(listOf(a, b), 0f, ht * end), size = Size(w, ht * end))
    when (id) {
        0 -> {
            sky(col(0x05080F), col(0x1B2A3A), 0.6f)
            drawRect(col(0x0F1C28), Offset(0f, ht * 0.55f), Size(w, ht * 0.25f))
            for (i in 0..5) drawLine(Color.White.copy(0.08f), Offset(w * 0.1f, ht * (0.58f + 0.03f * i)),
                Offset(w * (0.9f - 0.1f * (i % 2)), ht * (0.58f + 0.03f * i)), 2f)
            ridge(ht * 0.78f, ht * 0.006f, 16f, 0f, Color.White.copy(0.22f))
            ridge(ht * 0.795f, ht * 0.01f, 9f, 2f, col(0x090909))
        }
        1 -> { sky(col(0x000000), col(0x0B1020)); stars(90, 7, 0.9f) }
        2 -> {
            sky(col(0x070B16), col(0x1D2B45), 0.7f); stars(30, 3, 0.4f)
            ridge(ht * 0.6f, ht * 0.05f, 7f, 0.5f, col(0x131C2E))
            ridge(ht * 0.72f, ht * 0.05f, 9f, 2f, col(0x0B111D))
            ridge(ht * 0.85f, ht * 0.04f, 11f, 4f, col(0x04070C))
        }
        3 -> {
            sky(col(0x120B08), col(0x3A1F10), 0.7f)
            ridge(ht * 0.7f, ht * 0.04f, 5f, 0f, col(0x1E1009))
            ridge(ht * 0.85f, ht * 0.035f, 6f, 2f, col(0x0C0603))
        }
        4 -> {
            sky(col(0x03060C), col(0x10203A), 0.6f); stars(25, 5, 0.5f)
            drawCircle(Color.White.copy(0.08f), w * 0.15f, Offset(w * 0.7f, ht * 0.22f))
            drawCircle(col(0xE8E8D8), w * 0.06f, Offset(w * 0.7f, ht * 0.22f))
            drawRect(col(0x08121F), Offset(0f, ht * 0.6f), Size(w, ht * 0.4f))
            for (i in 0..6) drawLine(Color.White.copy(0.25f - 0.03f * i),
                Offset(w * (0.7f - 0.1f + 0.012f * i), ht * (0.62f + 0.04f * i)),
                Offset(w * (0.7f + 0.1f - 0.012f * i), ht * (0.62f + 0.04f * i)), 3f)
        }
        5 -> {
            sky(col(0x04100C), col(0x0F2A20), 0.8f)
            for (i in 0..14) {
                val x = w * i / 14f
                val th = ht * (0.15f + 0.1f * ((i * 7) % 5) / 4f)
                val tw = w * 0.07f
                val p = Path()
                p.moveTo(x - tw, ht); p.lineTo(x, ht - th); p.lineTo(x + tw, ht); p.close()
                drawPath(p, col(0x030806))
            }
        }
        6 -> {
            sky(col(0x02060A), col(0x061A1E)); stars(40, 9, 0.6f)
            repeat(3) { i ->
                val y = ht * (0.2f + 0.12f * i)
                rotate(-20f) {
                    drawRect(Brush.verticalGradient(
                        listOf(Color.Transparent, col(0x2AFFB0).copy(0.22f), Color.Transparent), y, y + ht * 0.09f),
                        Offset(-w, y), Size(w * 3, ht * 0.09f))
                }
            }
        }
        7 -> {
            sky(col(0x050816), col(0x16213A))
            val r = Random(3)
            var x = 0f
            while (x < w) {
                val bw = w * (0.05f + 0.05f * r.nextFloat())
                val bh = ht * (0.12f + 0.25f * r.nextFloat())
                drawRect(col(0x04060C), Offset(x, ht - bh), Size(bw, bh))
                repeat(3) {
                    drawRect(Color(0xFFFFD27A).copy(0.35f),
                        Offset(x + bw * 0.8f * r.nextFloat(), ht - bh + bh * 0.9f * r.nextFloat()), Size(bw * 0.08f, bw * 0.08f))
                }
                x += bw + w * 0.005f
            }
        }
        8 -> {
            stars(40, 11, 0.7f)
            drawCircle(Brush.radialGradient(listOf(col(0x1C3A5C), col(0x050A12)), Offset(w * 0.5f, ht * 1.0f), w * 0.9f),
                w * 0.9f, Offset(w * 0.5f, ht * 1.05f))
        }
        9 -> {
            sky(col(0x030A14), col(0x0A2038))
            for (i in 0..6) ridge(ht * (0.45f + 0.08f * i), ht * 0.02f, 6f + i, i.toFloat(), Color(0xFF3A7BD5).copy(0.07f))
        }
        10 -> {
            sky(col(0x0A0614), col(0x3A1426), 0.7f)
            drawCircle(col(0xFF8A3D).copy(0.6f), w * 0.12f, Offset(w * 0.5f, ht * 0.62f))
            ridge(ht * 0.68f, ht * 0.015f, 6f, 0f, col(0x0A0608))
        }
        12 -> {
            sky(col(0x0B1020), col(0x000000))
            val bh = ht * 0.025f
            fun bar(wf: Float, y: Float, c: Color) =
                drawRoundRect(c, Offset(w * 0.85f - w * wf, ht * y), Size(w * wf, bh), CornerRadius(bh / 2))
            bar(0.5f, 0.40f, Color.White.copy(0.9f))
            bar(0.3f, 0.46f, col(0x80CBC4))
            bar(0.4f, 0.52f, Color.White.copy(0.9f))
        }
        11 -> {
            for (i in 1..5) drawCircle(Color.White.copy(0.06f), w * 0.18f * i, Offset(w * 0.5f, ht * 0.5f), style = Stroke(2f))
        }
    }
}

object CustomBg { var bmp by mutableStateOf<ImageBitmap?>(null) }

fun loadCustom(ctx: Context): ImageBitmap? = try {
    val f = java.io.File(ctx.filesDir, "bg.jpg")
    if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
} catch (e: Exception) { null }

fun saveCustom(ctx: Context, uri: Uri): Boolean = try {
    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
    var sample = 1
    while (minOf(o.outWidth, o.outHeight) / (sample * 2) >= 1080) sample *= 2
    val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
    if (bmp == null) false else {
        java.io.File(ctx.filesDir, "bg.jpg").outputStream().use {
            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it)
        }
        true
    }
} catch (e: Exception) { false }

@Composable
fun BgView(bg: Bg, wallpaperAlpha: Float, modifier: Modifier) {
    Box(modifier.then(bgModifier(bg.colors, wallpaperAlpha))) {
        if (bg.motif == 99) {
            val b = CustomBg.bmp
            if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else if (bg.motif >= 0) Canvas(Modifier.fillMaxSize()) { motif(bg.motif) }
    }
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalContentColor provides Color.White) { Launcher(tick) }
            }
        }
    }
    override fun onResume() { super.onResume(); tick++ }
}

fun loadApps(ctx: Context): List<AppItem> {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return ctx.packageManager.queryIntentActivities(i, 0)
        .map { AppItem(it.loadLabel(ctx.packageManager).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun launch(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

fun setTorch(ctx: Context, on: Boolean) {
    try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return
        cm.setTorchMode(id, on)
    } catch (e: Exception) { }
}

fun weatherText(code: Int) = when (code) {
    0 -> "Klar"; 1, 2 -> "Heiter"; 3 -> "Bewölkt"; 45, 48 -> "Nebel"
    in 51..57 -> "Nieselregen"; in 61..67 -> "Regen"; in 71..77 -> "Schnee"
    in 80..82 -> "Schauer"; in 95..99 -> "Gewitter"; else -> "–"
}

suspend fun fetchWeather(ctx: Context): String = withContext(Dispatchers.IO) {
    try {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return@withContext "Wetter: Standort erlauben"
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = lm.getProviders(true)
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null } }
            .maxByOrNull { it.time } ?: return@withContext "Wetter: kein Standort"
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}" +
            "&longitude=${loc.longitude}&current=temperature_2m,weather_code"
        val cur = JSONObject(URL(url).readText()).getJSONObject("current")
        "${cur.getDouble("temperature_2m").roundToInt()}°  ${weatherText(cur.getInt("weather_code"))}"
    } catch (e: Exception) { "Wetter nicht verfügbar" }
}

@Composable
fun Launcher(tick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val apps = remember(tick) { loadApps(ctx) }
    var favs by remember { mutableStateOf(prefs.getString("favs", "")!!.split("|").filter { it.isNotEmpty() }) }
    fun toggleFav(pkg: String) {
        favs = if (pkg in favs) favs - pkg else favs + pkg
        prefs.edit().putString("favs", favs.joinToString("|")).apply()
    }
    var bg by remember { mutableIntStateOf(prefs.getInt("bg", 1).coerceIn(0, BACKGROUNDS.size - 1)) }
    LaunchedEffect(Unit) { CustomBg.bmp = withContext(Dispatchers.IO) { loadCustom(ctx) } }
    var browse by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }
    val badges by NotificationService.counts.collectAsState()
    BackHandler(browse || picker) { browse = false; picker = false }

    Box(
        Modifier.fillMaxSize().pointerInput(Unit) {
            var acc = 0f
            detectVerticalDragGestures(
                onDragStart = { acc = 0f },
                onDragEnd = { if (acc < -150f && !picker && !browse) browse = true }
            ) { _, d -> acc += d }
        }
    ) {
        BgView(BACKGROUNDS[bg], 0.35f, Modifier.fillMaxSize())
        if (BACKGROUNDS[bg].motif == 99 && !browse) Box(Modifier.fillMaxSize().background(Color.Black.copy(0.25f)))
        if (browse) Box(Modifier.fillMaxSize().background(Color.Black.copy(0.6f)))
        if (picker) BgPicker(bg, { bg = it; prefs.edit().putInt("bg", it).apply() }) { picker = false }
        else Home(apps, favs, badges, tick, browse, { browse = it }, ::toggleFav) { picker = true }
    }
}

@Composable
fun RoundButton(on: Boolean, modifier: Modifier, onClick: () -> Unit, icon: DrawScope.() -> Unit) {
    Box(modifier.size(56.dp).clip(CircleShape)
        .background(if (on) Color(0xFFE8EAED) else Color(0xCC202124)).clickable { onClick() },
        contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(24.dp)) { icon() }
    }
}

fun DrawScope.flashIcon(c: Color) {
    val w = size.width
    drawRoundRect(c, Offset(w * 0.3f, w * 0.05f), Size(w * 0.4f, w * 0.22f), CornerRadius(w * 0.05f))
    drawRoundRect(c, Offset(w * 0.36f, w * 0.32f), Size(w * 0.28f, w * 0.63f), CornerRadius(w * 0.06f))
}

fun DrawScope.cameraIcon(c: Color, hole: Color) {
    val w = size.width
    drawRoundRect(c, Offset(w * 0.35f, w * 0.12f), Size(w * 0.3f, w * 0.2f), CornerRadius(w * 0.05f))
    drawRoundRect(c, Offset(w * 0.05f, w * 0.25f), Size(w * 0.9f, w * 0.65f), CornerRadius(w * 0.12f))
    drawCircle(hole, w * 0.2f, Offset(w * 0.5f, w * 0.57f))
}

@Composable
fun Home(apps: List<AppItem>, favs: List<String>, badges: Map<String, Int>, tick: Int,
         browse: Boolean, setBrowse: (Boolean) -> Unit, onFav: (String) -> Unit, onBg: () -> Unit) {
    val ctx = LocalContext.current
    val time by produceState("", tick) {
        while (true) {
            value = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            delay(60_000 - System.currentTimeMillis() % 60_000 + 50)
        }
    }
    var battery by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
                val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                battery = "Akku ${lvl * 100 / scale} %" + if (ch) " ⚡" else ""
            }
        }
        ContextCompat.registerReceiver(ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { ctx.unregisterReceiver(r) }
    }
    var permTick by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permTick++ }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) permLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }
    var weather by remember { mutableStateOf("Wetter …") }
    LaunchedEffect(tick, permTick) { weather = fetchWeather(ctx) }

    var torch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(browse) { if (!browse) query = "" }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val focus = remember { FocusRequester() }
    fun letterOf(a: AppItem) = a.label.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#'
    val list = remember(apps, query) {
        val q = query.trim()
        if (q.isEmpty()) apps else {
            val starts = apps.filter { it.label.startsWith(q, true) }
            val words = apps.filter { a -> a !in starts && a.label.split(' ', '-', '.').any { it.startsWith(q, true) } }
            val rest = apps.filter { a -> a !in starts && a !in words && a.label.contains(q, true) }
            starts + words + rest
        }
    }
    val letters = remember(list) { list.map { letterOf(it) }.distinct() }

    var homeTick by remember { mutableIntStateOf(0) }
    val isDefault = remember(tick, homeTick) {
        ctx.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == ctx.packageName
    }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { homeTick++ }
    fun askDefault() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = ctx.getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME)); return
                }
            }
            ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) { }
    }
    val asked = remember { ctx.getSharedPreferences("p", 0) }
    val date = SimpleDateFormat("EEEE, d. MMMM", Locale.getDefault()).format(Date())
    LaunchedEffect(permTick) {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!isDefault && !asked.getBoolean("askedHome", false) && (granted || permTick > 0)) {
            asked.edit().putBoolean("askedHome", true).apply()
            delay(800)
            askDefault()
        }
    }
    val notifOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val white = Color.White
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()
            .padding(top = 16.dp, bottom = if (browse) 16.dp else 96.dp, end = 48.dp),
            horizontalAlignment = Alignment.End) {
            Text(time, color = white, fontSize = 64.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(horizontal = 24.dp))
            Text(date, fontSize = 16.sp, color = white.copy(0.7f), modifier = Modifier.padding(horizontal = 24.dp))
            Row(Modifier.padding(horizontal = 24.dp, vertical = 4.dp)) {
                Text(weather, fontSize = 16.sp, color = white.copy(0.85f),
                    modifier = Modifier.clickable { permLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION) })
                Text("  ·  $battery", fontSize = 16.sp, color = white.copy(0.85f))
            }
            if (browse) {
                OutlinedTextField(query, { query = it }, singleLine = true,
                    placeholder = { Text("App suchen") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let { launch(ctx, it.pkg) } }),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp).focusRequester(focus))
                LazyColumn(state = state, horizontalAlignment = Alignment.End,
                    modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(list, key = { it.pkg }) { app ->
                        AppRow(app, app.pkg in favs, badges[app.pkg] ?: 0, 24.sp, true) { onFav(app.pkg) }
                    }
                }
                Text("Favoriten", color = white.copy(0.7f), fontSize = 16.sp,
                    modifier = Modifier.clickable { setBrowse(false) }.padding(horizontal = 24.dp, vertical = 8.dp))
            } else {
                Spacer(Modifier.weight(1f))
                favs.mapNotNull { f -> apps.find { it.pkg == f } }.forEach {
                    AppRow(it, true, badges[it.pkg] ?: 0, 30.sp, true) { onFav(it.pkg) }
                }
                if (favs.isEmpty()) Text("Wische am rechten Rand oder nach oben und halte eine App gedrückt, um sie hier anzuheften.",
                    color = white.copy(0.6f), modifier = Modifier.padding(24.dp))
                Spacer(Modifier.height(16.dp))
                if (!isDefault) Text("Als Standard-Launcher festlegen", color = Color(0xFF80CBC4), fontSize = 14.sp,
                    modifier = Modifier.clickable { askDefault() }.padding(horizontal = 24.dp, vertical = 8.dp))
                if (!notifOn) Text("Benachrichtigungen aktivieren", color = Color(0xFF80CBC4), fontSize = 14.sp,
                    modifier = Modifier.clickable {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }.padding(horizontal = 24.dp, vertical = 8.dp))
                Text("Hintergrund · v7", color = white.copy(0.7f), fontSize = 16.sp,
                    modifier = Modifier.clickable { onBg() }.padding(horizontal = 24.dp, vertical = 8.dp))
                Text("Alle Apps", color = white.copy(0.7f), fontSize = 16.sp,
                    modifier = Modifier.clickable { setBrowse(true) }.padding(horizontal = 24.dp, vertical = 8.dp))
            }
        }
        if (!browse) {
            RoundButton(false, Modifier.align(Alignment.BottomStart).systemBarsPadding().padding(24.dp),
                { try { ctx.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) } catch (e: Exception) { } }
            ) { cameraIcon(Color.White, Color(0xFF202124)) }
            RoundButton(torch, Modifier.align(Alignment.BottomEnd).systemBarsPadding().padding(24.dp),
                { torch = !torch; setTorch(ctx, torch) }
            ) { flashIcon(if (torch) Color(0xFF202124) else Color.White) }
        }
        val sliderItems = listOf("Suche") + letters.map { it.toString() }
        LetterSlider(sliderItems, browse,
            Modifier.align(Alignment.CenterEnd).systemBarsPadding().padding(vertical = 24.dp)) { c ->
            setBrowse(true)
            if (c == "Suche") {
                scope.launch {
                    state.scrollToItem(0)
                    delay(200)
                    try { focus.requestFocus() } catch (e: Exception) { }
                }
            } else {
                val idx = list.indexOfFirst { letterOf(it).toString() == c }
                if (idx >= 0) scope.launch { state.scrollToItem(idx) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRow(app: AppItem, isFav: Boolean, badge: Int, size: TextUnit, icons: Boolean, onFav: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.combinedClickable(onClick = { launch(ctx, app.pkg) }, onLongClick = { menu = true })
                .padding(horizontal = 24.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icons) {
                val bmp = remember(app.pkg) {
                    try { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }
                    catch (e: Exception) { null }
                }
                if (bmp != null) Image(bmp, null, Modifier.size(40.dp))
                Spacer(Modifier.width(16.dp))
            }
            if (badge > 0) Text("$badge", color = Color(0xFF80CBC4), fontSize = 14.sp, modifier = Modifier.padding(end = 8.dp))
            Text(app.label, color = Color.White, fontSize = size, maxLines = 1)
        }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text(if (isFav) "Von Favoriten entfernen" else "Zu Favoriten") },
                onClick = { menu = false; onFav() })
            DropdownMenuItem(text = { Text("App-Info") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
            })
            DropdownMenuItem(text = { Text("Deinstallieren") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            })
        }
    }
}

@Composable
fun BgPicker(sel: Int, onSel: (Int) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { saveCustom(ctx, uri) }
            if (ok) {
                CustomBg.bmp = withContext(Dispatchers.IO) { loadCustom(ctx) }
                onSel(BACKGROUNDS.indexOfFirst { it.motif == 99 })
            }
        }
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Hintergrund", fontSize = 24.sp, modifier = Modifier.weight(1f).padding(8.dp))
            Text("Eigenes Bild", color = Color.White.copy(0.8f), fontSize = 16.sp,
                modifier = Modifier.clickable { pick.launch("image/*") }.padding(8.dp))
            Text("Fertig", color = Color(0xFF80CBC4), fontSize = 18.sp,
                modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }
        LazyVerticalGrid(GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(BACKGROUNDS) { i, item ->
                val shape = RoundedCornerShape(12.dp)
                val tm = Modifier.fillMaxWidth().aspectRatio(0.75f).clip(shape)
                    .border(if (i == sel) 3.dp else 1.dp, if (i == sel) Color.White else Color.Gray, shape)
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                    if (item.motif == 99 && CustomBg.bmp == null) pick.launch("image/*") else onSel(i)
                }) {
                    if (item.motif == 99 && CustomBg.bmp == null) Box(tm.background(Color(0xFF202124)), contentAlignment = Alignment.Center) { Text("+", fontSize = 32.sp) }
                    else if (item.colors.isEmpty() && item.motif < 0) Box(tm.background(Color.Gray))
                    else BgView(item, 0.35f, tm)
                    Text(item.name, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
fun LetterSlider(labels: List<String>, visible: Boolean, modifier: Modifier, onSelect: (String) -> Unit) {
    var active by remember { mutableFloatStateOf(-1f) }
    var last by remember { mutableIntStateOf(-1) }
    var hgt by remember { mutableIntStateOf(1) }
    val sel by rememberUpdatedState(onSelect)
    fun update(y: Float) {
        val i = (y / hgt * labels.size).coerceIn(0f, labels.size - 1f)
        active = i
        if (i.toInt() != last) { last = i.toInt(); sel(labels[i.toInt()]) }
    }
    val show = visible || active >= 0f
    Column(
        modifier.fillMaxHeight().width(48.dp).onSizeChanged { hgt = it.height }
            .pointerInput(labels) {
                detectDragGestures(
                    onDragStart = { update(it.y) },
                    onDragEnd = { active = -1f; last = -1 },
                    onDragCancel = { active = -1f; last = -1 }
                ) { change, _ -> update(change.position.y) }
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        labels.forEachIndexed { i, c ->
            val d = if (active < 0) 99f else i - active
            val wave = exp(-(d * d) / 3.0).toFloat()
            val base = if (c.length > 1) 11 else 12
            Text(c, color = Color.White.copy(if (show) 0.5f + 0.5f * wave else 0f),
                fontSize = (base + 10 * wave).sp, maxLines = 1,
                modifier = Modifier.offset { IntOffset((-60 * wave).roundToInt(), 0) })
        }
    }
}
