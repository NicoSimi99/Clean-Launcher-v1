package com.example.niagara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.exp
import kotlin.math.roundToInt

data class AppItem(val label: String, val pkg: String)

fun h(x: Int) = Color(0xFF000000.toInt() or x)

// Leere Liste = System-Wallpaper. Dunkle Farben sparen Akku auf OLED-Displays.
val BACKGROUNDS: List<Pair<String, List<Color>>> = listOf(
    "Wallpaper" to emptyList(),
    "Schwarz" to listOf(h(0x000000)),
    "Anthrazit" to listOf(h(0x121212)),
    "Mitternacht" to listOf(h(0x0B1020)),
    "Tiefblau" to listOf(h(0x0A1A2F)),
    "Ozean" to listOf(h(0x06202B)),
    "Wald" to listOf(h(0x0B1A14)),
    "Moos" to listOf(h(0x101A0E)),
    "Bordeaux" to listOf(h(0x1E0A10)),
    "Aubergine" to listOf(h(0x1A0B1F)),
    "Schiefer" to listOf(h(0x1C1F26)),
    "Kohle" to listOf(h(0x1A1A1A)),
    "Espresso" to listOf(h(0x1B1410)),
    "Dämmerung" to listOf(h(0x0B1020), h(0x1B1030)),
    "Nordlicht" to listOf(h(0x04121A), h(0x0B2A2A)),
    "Glut" to listOf(h(0x150808), h(0x2A0F0A)),
    "Violett" to listOf(h(0x0F0A1F), h(0x2A1040)),
    "Tiefsee" to listOf(h(0x000000), h(0x0A2540)),
    "Graphit" to listOf(h(0x000000), h(0x202226)),
    "Smaragd" to listOf(h(0x000000), h(0x0A2A1E)),
    "Rosé" to listOf(h(0x1A0A12), h(0x2E1020))
)

fun bgModifier(cols: List<Color>, wallpaperAlpha: Float): Modifier = when (cols.size) {
    0 -> Modifier.background(Color.Black.copy(alpha = wallpaperAlpha))
    1 -> Modifier.background(cols[0])
    else -> Modifier.background(Brush.verticalGradient(cols))
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Launcher(tick) } }
    }
    override fun onResume() { super.onResume(); tick++ }
}

fun loadApps(ctx: Context): List<AppItem> {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return ctx.packageManager.queryIntentActivities(i, 0)
        .map { AppItem(it.loadLabel(ctx.packageManager).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun launch(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

fun weatherText(code: Int) = when (code) {
    0 -> "Klar"; 1, 2 -> "Heiter"; 3 -> "Bewölkt"; 45, 48 -> "Nebel"
    in 51..57 -> "Nieselregen"; in 61..67 -> "Regen"; in 71..77 -> "Schnee"
    in 80..82 -> "Schauer"; in 95..99 -> "Gewitter"; else -> "–"
}

suspend fun fetchWeather(ctx: Context): String = withContext(Dispatchers.IO) {
    try {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return@withContext "Wetter: Standort erlauben"
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = lm.getProviders(true)
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null } }
            .maxByOrNull { it.time } ?: return@withContext "Wetter: kein Standort"
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}" +
            "&longitude=${loc.longitude}&current=temperature_2m,weather_code"
        val cur = JSONObject(URL(url).readText()).getJSONObject("current")
        "${cur.getDouble("temperature_2m").roundToInt()}°  ${weatherText(cur.getInt("weather_code"))}"
    } catch (e: Exception) { "Wetter nicht verfügbar" }
}

@Composable
fun Launcher(tick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val apps = remember(tick) { loadApps(ctx) }
    var favs by remember { mutableStateOf(prefs.getString("favs", "")!!.split("|").filter { it.isNotEmpty() }) }
    fun toggleFav(pkg: String) {
        favs = if (pkg in favs) favs - pkg else favs + pkg
        prefs.edit().putString("favs", favs.joinToString("|")).apply()
    }
    var bg by remember { mutableIntStateOf(prefs.getInt("bg", 1).coerceIn(0, BACKGROUNDS.size - 1)) }
    var drawer by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }
    val badges by NotificationService.counts.collectAsState()
    BackHandler(drawer || picker) { drawer = false; picker = false }

    Box(
        Modifier.fillMaxSize()
            .then(bgModifier(BACKGROUNDS[bg].second, if (drawer) 0.85f else 0.35f))
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc < -150f && !picker) drawer = true }
                ) { _, d -> acc += d }
            }
    ) {
        when {
            picker -> BgPicker(bg, { bg = it; prefs.edit().putInt("bg", it).apply() }) { picker = false }
            drawer -> Drawer(apps, favs, badges, ::toggleFav)
            else -> Home(apps, favs, badges, tick, ::toggleFav, onAll = { drawer = true }, onBg = { picker = true })
        }
    }
}

@Composable
fun Home(apps: List<AppItem>, favs: List<String>, badges: Map<String, Int>, tick: Int,
         onFav: (String) -> Unit, onAll: () -> Unit, onBg: () -> Unit) {
    val ctx = LocalContext.current
    val time by produceState("", tick) {
        while (true) {
            value = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); delay(10_000)
        }
    }
    val battery by produceState("", tick) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0
            val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            value = "Akku ${lvl * 100 / scale} %" + if (ch) " ⚡" else ""
            delay(15_000)
        }
    }
    var permTick by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permTick++ }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) permLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }
    var weather by remember { mutableStateOf("Wetter …") }
    LaunchedEffect(tick, permTick) { weather = fetchWeather(ctx) }

    val date = SimpleDateFormat("EEEE, d. MMMM", Locale.getDefault()).format(Date())
    val notifOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(vertical = 16.dp), horizontalAlignment = Alignment.End) {
        Text(time, fontSize = 64.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(horizontal = 24.dp))
        Text(date, fontSize = 16.sp, color = Color.White.copy(0.7f), modifier = Modifier.padding(horizontal = 24.dp))
        Row(Modifier.padding(horizontal = 24.dp, vertical = 4.dp)) {
            Text(weather, fontSize = 16.sp, color = Color.White.copy(0.85f),
                modifier = Modifier.clickable { permLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION) })
            Text("  ·  $battery", fontSize = 16.sp, color = Color.White.copy(0.85f))
        }
        Spacer(Modifier.weight(1f))
        favs.mapNotNull { f -> apps.find { it.pkg == f } }.forEach {
            AppRow(it, true, badges[it.pkg] ?: 0, 30.sp, true) { onFav(it.pkg) }
        }
        if (favs.isEmpty()) Text("Wische nach oben und halte eine App gedrückt, um sie hier anzuheften.",
            color = Color.White.copy(0.6f), modifier = Modifier.padding(24.dp))
        Spacer(Modifier.height(16.dp))
        if (!notifOn) Text("Benachrichtigungen aktivieren", color = Color(0xFF80CBC4), fontSize = 14.sp,
            modifier = Modifier.clickable {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }.padding(horizontal = 24.dp, vertical = 8.dp))
        Text("Hintergrund", color = Color.White.copy(0.7f), fontSize = 16.sp,
            modifier = Modifier.clickable { onBg() }.padding(horizontal = 24.dp, vertical = 8.dp))
        Text("Alle Apps", color = Color.White.copy(0.7f), fontSize = 16.sp,
            modifier = Modifier.clickable { onAll() }.padding(horizontal = 24.dp, vertical = 8.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRow(app: AppItem, isFav: Boolean, badge: Int, size: TextUnit, icons: Boolean, onFav: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.combinedClickable(onClick = { launch(ctx, app.pkg) }, onLongClick = { menu = true })
                .padding(horizontal = 24.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icons) {
                val bmp = remember(app.pkg) {
                    try { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }
                    catch (e: Exception) { null }
                }
                if (bmp != null) Image(bmp, null, Modifier.size(40.dp))
                Spacer(Modifier.width(16.dp))
            }
            if (badge > 0) Text("$badge", color = Color(0xFF80CBC4), fontSize = 14.sp, modifier = Modifier.padding(end = 8.dp))
            Text(app.label, color = Color.White, fontSize = size, maxLines = 1)
        }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text(if (isFav) "Von Favoriten entfernen" else "Zu Favoriten") },
                onClick = { menu = false; onFav() })
            DropdownMenuItem(text = { Text("App-Info") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
            })
            DropdownMenuItem(text = { Text("Deinstallieren") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            })
        }
    }
}

@Composable
fun BgPicker(sel: Int, onSel: (Int) -> Unit, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Hintergrund", fontSize = 24.sp, modifier = Modifier.weight(1f).padding(8.dp))
            Text("Fertig", color = Color(0xFF80CBC4), fontSize = 18.sp,
                modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }
        LazyVerticalGrid(GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(BACKGROUNDS) { i, item ->
                val shape = RoundedCornerShape(12.dp)
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSel(i) }) {
                    Box(Modifier.fillMaxWidth().aspectRatio(0.75f).clip(shape)
                        .then(bgModifier(item.second, 0.35f).let { if (item.second.isEmpty()) Modifier.background(Color.Gray) else it })
                        .border(if (i == sel) 3.dp else 1.dp, if (i == sel) Color.White else Color.Gray, shape))
                    Text(item.first, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
fun Drawer(apps: List<AppItem>, favs: List<String>, badges: Map<String, Int>, onFav: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val list = remember(apps, query) { apps.filter { it.label.contains(query, true) } }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    fun letterOf(a: AppItem) = a.label.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#'
    val letters = remember(list) { list.map { letterOf(it) }.distinct() }
    Row(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.weight(1f)) {
            OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("Suchen") },
                modifier = Modifier.fillMaxWidth().padding(16.dp))
            LazyColumn(state = state, modifier = Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { app ->
                    AppRow(app, app.pkg in favs, badges[app.pkg] ?: 0, 22.sp, true) { onFav(app.pkg) }
                }
            }
        }
        if (letters.isNotEmpty()) LetterSlider(letters) { c ->
            val idx = list.indexOfFirst { letterOf(it) == c }
            if (idx >= 0) scope.launch { state.scrollToItem(idx) }
        }
    }
}

@Composable
fun LetterSlider(letters: List<Char>, onSelect: (Char) -> Unit) {
    var active by remember { mutableFloatStateOf(-1f) }
    var hgt by remember { mutableIntStateOf(1) }
    fun update(y: Float) {
        val i = (y / hgt * letters.size).coerceIn(0f, letters.size - 1f)
        active = i; onSelect(letters[i.toInt()])
    }
    Column(
        Modifier.fillMaxHeight().width(56.dp).onSizeChanged { hgt = it.height }
            .pointerInput(letters) {
                detectDragGestures(
                    onDragStart = { update(it.y) },
                    onDragEnd = { active = -1f },
                    onDragCancel = { active = -1f }
                ) { change, _ -> update(change.position.y) }
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEachIndexed { i, c ->
            val d = if (active < 0) 99f else i - active
            val wave = exp(-(d * d) / 3.0).toFloat()
            Text("$c", color = Color.White.copy(0.5f + 0.5f * wave), fontSize = (13 + 12 * wave).sp,
                modifier = Modifier.offset { IntOffset((-70 * wave).roundToInt(), 0) })
        }
    }
}
