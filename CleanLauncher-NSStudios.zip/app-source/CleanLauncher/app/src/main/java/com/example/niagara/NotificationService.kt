package at.nsstudios.cleanlauncher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow

class NotificationService : NotificationListenerService() {
    companion object { val counts = MutableStateFlow<Map<String, Int>>(emptyMap()) }

    private fun refresh() {
        counts.value = try {
            activeNotifications.groupingBy { it.packageName }.eachCount()
        } catch (e: Exception) { emptyMap() }
    }
    override fun onListenerConnected() = refresh()
    override fun onNotificationPosted(sbn: StatusBarNotification) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = refresh()
}
